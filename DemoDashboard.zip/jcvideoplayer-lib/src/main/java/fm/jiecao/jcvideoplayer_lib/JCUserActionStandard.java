package fm.jiecao.jcvideoplayer_lib;

/**
 * Created by Nathen
 * On 2016/04/26 20:53
 */
public interface JCUserActionStandard extends JCUserAction {

    int ON_CLICK_START_THUMB = 101;
    int ON_CLICK_BLANK = 102;

}
